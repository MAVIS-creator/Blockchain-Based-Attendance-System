<?php
require_once __DIR__ . '/session_bootstrap.php';
admin_configure_session();
if (empty($_SESSION['admin_logged_in'])) {
  header('Location: login.php');
  exit;
}

require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/hybrid_admin_read.php';
require_once __DIR__ . '/../storage_helpers.php';
require_once __DIR__ . '/runtime_storage.php';
require_once __DIR__ . '/cache_helpers.php';
require_once __DIR__ . '/state_helpers.php';
require_once __DIR__ . '/includes/ai_recommendation_formatter.php';
require_once __DIR__ . '/../src/AiTicketAutomationEngine.php';
app_storage_init();
$pageCsrfToken = csrf_token();
$flashMessage = $_SESSION['admin_flash'] ?? null;
unset($_SESSION['admin_flash']);

$ticketsFile = admin_storage_migrate_file('support_tickets.json', app_storage_file('support_tickets.json'));
$tickets = [];
$ticketsSource = 'file';

$hybridTickets = hybrid_fetch_support_tickets($ticketsSource);
if (is_array($hybridTickets)) {
  $tickets = $hybridTickets;
} else if (file_exists($ticketsFile)) {
  $tickets = admin_cached_json_file('support_tickets_page', $ticketsFile, [], 15);
}

$today = date('Y-m-d');
$logFile = app_storage_file("logs/{$today}.log");
$logLines = admin_cached_file_lines('support_ticket_today_log', $logFile, 15);
$aiDiagnosticsFile = function_exists('ai_ticket_diagnostics_file')
  ? ai_ticket_diagnostics_file()
  : admin_storage_migrate_file('ai_ticket_diagnostics.json');
$aiDiagnostics = file_exists($aiDiagnosticsFile)
  ? admin_cached_json_file('ai_ticket_diagnostics', $aiDiagnosticsFile, [], 15)
  : [];
if (!is_array($aiDiagnostics)) {
  $aiDiagnostics = [];
}
$recentAiDiagnostics = array_slice($aiDiagnostics, 0, 8);
$diagnosticsByTicketTime = [];
foreach ($aiDiagnostics as $diag) {
  $ticketTime = trim((string)($diag['ticket_timestamp'] ?? ''));
  if ($ticketTime === '' || isset($diagnosticsByTicketTime[$ticketTime])) {
    continue;
  }
  $diagnosticsByTicketTime[$ticketTime] = $diag;
}

$unresolvedTickets = array_values(array_filter($tickets, static function ($ticket) {
  return is_array($ticket) && empty($ticket['resolved']);
}));

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && !empty($unresolvedTickets)) {
  try {
    $engine = new AiTicketAutomationEngine();
    $autoRun = $engine->autoProcessPending(min(20, count($unresolvedTickets)), 'support_tickets_page', 15);
    if (!empty($autoRun['ok']) && (int)($autoRun['processed'] ?? 0) > 0) {
      $ticketsSource = 'file';
      $reloadedHybrid = hybrid_fetch_support_tickets($ticketsSource);
      if (is_array($reloadedHybrid)) {
        $tickets = $reloadedHybrid;
      } else if (file_exists($ticketsFile)) {
        $rawTickets = json_decode((string)@file_get_contents($ticketsFile), true);
        $tickets = is_array($rawTickets) ? $rawTickets : [];
      }

      $rawDiagnostics = file_exists($aiDiagnosticsFile)
        ? json_decode((string)@file_get_contents($aiDiagnosticsFile), true)
        : [];
      $aiDiagnostics = is_array($rawDiagnostics) ? $rawDiagnostics : [];
      $recentAiDiagnostics = array_slice($aiDiagnostics, 0, 8);
    }
  } catch (\Throwable $e) {
    // Best-effort auto-processing only; the page should still render ticket data.
  }
}

function checkLogMatch($logLines, $needle, $index)
{
  foreach ($logLines as $line) {
    $fields = array_map('trim', explode('|', $line));
    if (isset($fields[$index]) && $fields[$index] === $needle) {
      return true;
    }
  }
  return false;
}

function resolve_ticket_atomic($ticketsFile, $resolveTime)
{
  $fp = fopen($ticketsFile, 'c+');
  if (!$fp) return false;
  if (!flock($fp, LOCK_EX)) {
    fclose($fp);
    return false;
  }

  rewind($fp);
  $raw = stream_get_contents($fp);
  $tickets = json_decode($raw ?: '[]', true);
  if (!is_array($tickets)) $tickets = [];

  foreach ($tickets as &$ticket) {
    if (($ticket['timestamp'] ?? '') === $resolveTime) {
      $ticket['resolved'] = true;
      break;
    }
  }

  $payload = json_encode($tickets, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  rewind($fp);
  ftruncate($fp, 0);
  fwrite($fp, $payload);
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);

  return true;
}

function bulk_update_tickets_atomic($ticketsFile, array $selectedTimes, $bulkAction, $logFile = null, $activeCourse = '')
{
  $bulkAction = strtolower(trim((string)$bulkAction));
  $allowedActions = ['resolve', 'checkin', 'checkout'];
  if (!in_array($bulkAction, $allowedActions, true)) {
    return ['updated' => 0, 'logged' => 0];
  }

  $selectedLookup = array_fill_keys(array_filter(array_map('strval', $selectedTimes)), true);
  if (!$selectedLookup) {
    return ['updated' => 0, 'logged' => 0];
  }

  $attendanceAction = $bulkAction === 'checkin' ? 'checkin' : ($bulkAction === 'checkout' ? 'checkout' : '');
  $timestamp = date('Y-m-d H:i:s');
  $updatedCount = 0;
  $logLines = [];

  $fp = fopen($ticketsFile, 'c+');
  if (!$fp) return ['updated' => 0, 'logged' => 0];
  if (!flock($fp, LOCK_EX)) {
    fclose($fp);
    return ['updated' => 0, 'logged' => 0];
  }

  rewind($fp);
  $raw = stream_get_contents($fp);
  $tickets = json_decode($raw ?: '[]', true);
  if (!is_array($tickets)) $tickets = [];

  foreach ($tickets as &$ticket) {
    $ticketTime = (string)($ticket['timestamp'] ?? '');
    if (!isset($selectedLookup[$ticketTime])) {
      continue;
    }

    if (!($ticket['resolved'] ?? false)) {
      $ticket['resolved'] = true;
      $updatedCount++;
    }

    if ($attendanceAction !== '') {
      $name = trim((string)($ticket['name'] ?? 'Unknown'));
      $matric = trim((string)($ticket['matric'] ?? ''));
      $reason = trim((string)($ticket['message'] ?? 'Bulk support ticket action'));
      $logLines[] = "{$name} | {$matric} | {$attendanceAction} | MANUAL | ::1 | UNKNOWN | {$timestamp} | Bulk Ticket Panel | {$activeCourse} | {$reason}\n";
    }
  }
  unset($ticket);

  $payload = json_encode($tickets, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  rewind($fp);
  ftruncate($fp, 0);
  fwrite($fp, $payload);
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);

  if (!empty($logLines) && $logFile) {
    file_put_contents($logFile, implode('', $logLines), FILE_APPEND | LOCK_EX);
  }

  return ['updated' => $updatedCount, 'logged' => count($logLines)];
}

// Handle resolve
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve_ticket'])) {
  if (!csrf_check_request()) {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Invalid CSRF token', 'text' => 'Please refresh the page and try again.'];
    header("Location: index.php?page=support_tickets");
    exit;
  }
  $resolveTime = trim((string)($_POST['resolve_ticket'] ?? ''));
  if ($resolveTime === '') {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Resolve failed', 'text' => 'Ticket timestamp is missing.'];
    header("Location: index.php?page=support_tickets");
    exit;
  }
  hybrid_mark_support_ticket_resolved($resolveTime);
  $resolved = resolve_ticket_atomic($ticketsFile, $resolveTime);

  if ($resolved) {
    require_once __DIR__ . '/state_helpers.php';
    if (function_exists('admin_log_action')) {
      admin_log_action('Settings', 'Ticket Resolved', "Support ticket resolved (Timestamp: $resolveTime)");
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'title' => 'Resolved', 'text' => 'Ticket marked as resolved.'];
  } else {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Resolve failed', 'text' => 'Could not update the ticket file.'];
  }
  header("Location: index.php?page=support_tickets");
  exit;
}

// Handle manual check-in/out
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_action'], $_POST['name'], $_POST['matric'], $_POST['reason'])) {
  if (!csrf_check_request()) {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Invalid CSRF token', 'text' => 'Please refresh the page and try again.'];
    header("Location: index.php?page=support_tickets");
    exit;
  }

  $action = $_POST['manual_action'];
  $name = trim($_POST['name']);
  $matric = trim($_POST['matric']);
  $reason = trim($_POST['reason']);

  $activeCourse = admin_active_course_name_cached(15);

  $timestamp = date('Y-m-d H:i:s');
  $logFile = app_storage_file("logs/{$today}.log");

  // Standardized log format: name | matric | action | fingerprint | ip | mac | timestamp | userAgent | course | reason
  $line = "{$name} | {$matric} | {$action} | MANUAL | ::1 | UNKNOWN | {$timestamp} | Web Ticket Panel | {$activeCourse} | {$reason}\n";

  file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);

  require_once __DIR__ . '/state_helpers.php';
  if (function_exists('admin_log_action')) {
    admin_log_action('Attendance', 'Manual Ticket Attendance', "Logged manual $action for $name ($matric). Reason: $reason");
  }
  $_SESSION['admin_flash'] = ['type' => 'success', 'title' => 'Attendance recorded', 'text' => ucfirst($action) . ' was added from support tickets.'];
  header("Location: index.php?page=support_tickets");
  exit;
}

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'], $_POST['selected_tickets'])) {
  if (!csrf_check_request()) {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Invalid CSRF token', 'text' => 'Please refresh the page and try again.'];
    header("Location: index.php?page=support_tickets");
    exit;
  }

  $bulkAction = trim((string)$_POST['bulk_action']);
  $selectedTickets = array_values(array_filter(array_map('trim', (array)$_POST['selected_tickets'])));

  if (empty($selectedTickets)) {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Bulk action failed', 'text' => 'Select at least one ticket first.'];
    header("Location: index.php?page=support_tickets");
    exit;
  }

  $activeCourse = admin_active_course_name_cached(15);
  $result = bulk_update_tickets_atomic($ticketsFile, $selectedTickets, $bulkAction, $logFile, $activeCourse);
  $updatedCount = (int)($result['updated'] ?? 0);
  $loggedCount = (int)($result['logged'] ?? 0);

  foreach (array_unique($selectedTickets) as $resolveTime) {
    hybrid_mark_support_ticket_resolved($resolveTime);
  }

  if ($bulkAction === 'resolve') {
    require_once __DIR__ . '/state_helpers.php';
    if (function_exists('admin_log_action')) {
      admin_log_action('Settings', 'Bulk Tickets Resolved', "Resolved {$updatedCount} support ticket(s).");
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'title' => 'Bulk resolved', 'text' => "Resolved {$updatedCount} ticket(s)."];
  } elseif ($bulkAction === 'checkin') {
    require_once __DIR__ . '/state_helpers.php';
    if (function_exists('admin_log_action')) {
      admin_log_action('Attendance', 'Bulk Tickets Check-In', "Checked in {$updatedCount} ticket(s). Logged {$loggedCount} entry/entries. Active Course: $activeCourse");
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'title' => 'Bulk check-in', 'text' => "Checked in and resolved {$updatedCount} ticket(s). Logged {$loggedCount} attendance entry/entries."];
  } elseif ($bulkAction === 'checkout') {
    require_once __DIR__ . '/state_helpers.php';
    if (function_exists('admin_log_action')) {
      admin_log_action('Attendance', 'Bulk Tickets Check-Out', "Checked out {$updatedCount} ticket(s). Logged {$loggedCount} entry/entries. Active Course: $activeCourse");
    }
    $_SESSION['admin_flash'] = ['type' => 'success', 'title' => 'Bulk check-out', 'text' => "Checked out and resolved {$updatedCount} ticket(s). Logged {$loggedCount} attendance entry/entries."];
  } else {
    $_SESSION['admin_flash'] = ['type' => 'error', 'title' => 'Bulk action failed', 'text' => 'Unsupported bulk action.'];
  }

  header("Location: index.php?page=support_tickets");
  exit;
}

$allUnresolvedTickets = array_values(array_filter($tickets, static function ($ticket) {
  return is_array($ticket) && empty($ticket['resolved']);
}));
$allUnresolvedTickets = array_reverse($allUnresolvedTickets);

$ticketPerPage = 12;
$ticketPage = isset($_GET['tickets_pg']) ? (int)$_GET['tickets_pg'] : 1;
if ($ticketPage < 1) $ticketPage = 1;
$ticketTotal = count($allUnresolvedTickets);
$ticketTotalPages = max(1, (int)ceil($ticketTotal / $ticketPerPage));
if ($ticketPage > $ticketTotalPages) $ticketPage = $ticketTotalPages;
$ticketOffset = ($ticketPage - 1) * $ticketPerPage;
$ticketPageItems = array_slice($allUnresolvedTickets, $ticketOffset, $ticketPerPage);
?>

<!-- Support Tickets — Stitch UI -->
<div style="margin-bottom:24px;">
  <h2 style="font-size:1.5rem;font-weight:800;color:var(--on-surface);letter-spacing:-0.02em;margin:0;">
    <span class="material-symbols-outlined" style="vertical-align:middle;margin-right:8px;">confirmation_number</span>Support Tickets
  </h2>
  <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:4px;">
    <span style="color:var(--on-surface-variant);font-size:0.88rem;">Source: <strong><?= htmlspecialchars($ticketsSource) ?></strong></span>
    <a href="index.php?page=ai_suggestions" class="st-btn st-btn-sm" style="display:inline-flex;align-items:center;gap:6px;">
      <span class="material-symbols-outlined" style="font-size:1rem;">smart_toy</span>
      View AI Suggestions
    </a>
  </div>
</div>

<?php if (!empty($recentAiDiagnostics)): ?>
  <div style="margin:0 0 16px 0;padding:14px;background:var(--surface-container-lowest);border:1px solid var(--outline-variant);border-radius:12px;">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
      <strong style="font-size:0.95rem;color:var(--on-surface);display:inline-flex;align-items:center;gap:6px;">
        <span class="material-symbols-outlined" style="font-size:1.05rem;">smart_toy</span>
        AI Diagnostics (Recent)
      </strong>
      <span style="font-size:0.78rem;color:var(--on-surface-variant);">Last <?= (int)count($recentAiDiagnostics) ?> processed ticket(s)</span>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px;">
      <?php foreach ($recentAiDiagnostics as $diag): ?>
        <?php
        $diagClass = (string)($diag['classification'] ?? 'unknown');
        $diagConf = isset($diag['confidence']) ? (float)$diag['confidence'] : 0.0;
        $diagSeverityBg = '#eef6ff';
        $diagSeverityLine = '#cfe1f5';
        $diagSeverityText = '#1d4f80';
        if ($diagClass === 'blocked_revoked_device' || $diagClass === 'duplicate_or_fraudulent_sequence' || $diagClass === 'policy_device_sharing_risk') {
          $diagSeverityBg = '#ffeef0';
          $diagSeverityLine = '#f5c2c8';
          $diagSeverityText = '#9f1d2c';
        } elseif ($diagClass === 'network_ip_rotation' || $diagClass === 'new_or_suspicious_device') {
          $diagSeverityBg = '#fff8e8';
          $diagSeverityLine = '#f5dfad';
          $diagSeverityText = '#8a5a00';
        }
        ?>
        <div style="padding:10px;border-radius:10px;background:<?= $diagSeverityBg ?>;border:1px solid <?= $diagSeverityLine ?>;color:<?= $diagSeverityText ?>;">
          <div style="font-size:0.82rem;font-weight:700;margin-bottom:4px;word-break:break-word;"><?= htmlspecialchars($diagClass) ?></div>
          <div style="font-size:0.78rem;opacity:0.9;margin-bottom:4px;">Confidence: <?= htmlspecialchars(number_format($diagConf, 2)) ?></div>
          <div style="font-size:0.78rem;opacity:0.9;margin-bottom:4px;word-break:break-word;">Matric: <?= htmlspecialchars((string)($diag['matric'] ?? '-')) ?></div>
          <?php if (!empty($diag['decision_reason'])): ?>
            <div style="font-size:0.76rem;opacity:0.95;line-height:1.45;word-break:break-word;color:var(--on-surface);margin-top:6px;">
              <strong>Reason:</strong> <?= htmlspecialchars((string)$diag['decision_reason']) ?>
            </div>
          <?php endif; ?>
          <div style="font-size:0.76rem;opacity:0.95;line-height:1.45;word-break:break-word;color:var(--on-surface);margin-top:6px;">
            <?= ai_recommendation_render_html((string)($diag['suggested_admin_action'] ?? 'Review diagnostics.')) ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<form id="bulkTicketForm" method="post" style="margin:0 0 16px 0;">
  <?php csrf_field(); ?>
  <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-container-lowest);border:1px solid var(--outline-variant);border-radius:14px;box-shadow:var(--shadow-ambient);">
    <div style="display:flex;flex-direction:column;gap:4px;min-width:220px;">
      <strong style="color:var(--on-surface);font-size:0.95rem;">Bulk actions</strong>
      <span style="color:var(--on-surface-variant);font-size:0.82rem;">Select tickets below, then choose resolve, check-in, or check-out.</span>
    </div>
    <label style="display:inline-flex;align-items:center;gap:8px;color:var(--on-surface-variant);font-size:0.84rem;cursor:pointer;user-select:none;">
      <input type="checkbox" id="selectAllTickets" style="width:16px;height:16px;">
      Select all
    </label>
    <div style="display:flex;flex-wrap:wrap;gap:8px;">
      <button type="submit" name="bulk_action" value="resolve" class="st-btn st-btn-success st-btn-sm" style="display:inline-flex;align-items:center;gap:6px;">
        <span class="material-symbols-outlined" style="font-size:1rem;">task_alt</span> Bulk Resolve
      </button>
      <button type="submit" name="bulk_action" value="checkin" class="st-btn st-btn-sm" style="display:inline-flex;align-items:center;gap:6px;background:#0ea5e9;color:#fff;border-color:#0ea5e9;">
        <span class="material-symbols-outlined" style="font-size:1rem;">login</span> Bulk Check-In
      </button>
      <button type="submit" name="bulk_action" value="checkout" class="st-btn st-btn-sm" style="display:inline-flex;align-items:center;gap:6px;background:#7c3aed;color:#fff;border-color:#7c3aed;">
        <span class="material-symbols-outlined" style="font-size:1rem;">logout</span> Bulk Check-Out
      </button>
    </div>
  </div>
</form>

<div class="tickets-wrapper" style="grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));">
  <?php
  $hasUnresolved = !empty($allUnresolvedTickets);
  if (!empty($tickets)): ?>
    <?php foreach ($ticketPageItems as $ticket): ?>

      <?php
      $fp = $ticket['fingerprint'] ?? '';
      $ip = $ticket['ip'] ?? '';
      $fpMatch = $fp ? checkLogMatch($logLines, $fp, 3) : false;
      $ipMatch = $ip ? checkLogMatch($logLines, $ip, 4) : false;
      $ticketDiag = $diagnosticsByTicketTime[(string)($ticket['timestamp'] ?? '')] ?? null;
      $ticketDiagClass = trim((string)($ticketDiag['classification'] ?? ''));
      $ticketDiagReason = trim((string)($ticketDiag['decision_reason'] ?? ''));
      $ticketDiagSuggestion = trim((string)($ticketDiag['suggested_admin_action'] ?? ''));
      $ticketDiagProvider = trim((string)($ticketDiag['ai_provider'] ?? ''));
      $ticketDiagLatency = isset($ticketDiag['ai_latency_ms']) ? (int)$ticketDiag['ai_latency_ms'] : 0;
      ?>

      <div class="ticket-card" style="position:relative;overflow:visible;">
        <!-- Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--surface-container-high);">
          <label style="display:flex;align-items:center;gap:10px;cursor:pointer;max-width:72%;">
            <input type="checkbox" class="bulk-ticket-checkbox" form="bulkTicketForm" name="selected_tickets[]" value="<?= htmlspecialchars($ticket['timestamp']) ?>" style="width:16px;height:16px;accent-color:#1f5d99;">
            <strong style="color:var(--on-surface);font-size:1rem;"><?= htmlspecialchars($ticket['name']) ?></strong>
          </label>
          <span class="st-chip st-chip-info"><?= htmlspecialchars($ticket['matric']) ?></span>
        </div>

        <!-- Message -->
        <p style="color:var(--on-surface);line-height:1.6;margin-bottom:16px;font-size:0.9rem;">
          <?= nl2br(htmlspecialchars($ticket['message'])) ?>
        </p>

        <?php if (is_array($ticketDiag)): ?>
          <div style="display:grid;gap:8px;margin-bottom:16px;padding:12px 14px;border-radius:10px;background:var(--surface-container-lowest);border:1px solid var(--outline-variant);">
            <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
              <span class="st-chip st-chip-info"><?= htmlspecialchars($ticketDiagClass !== '' ? $ticketDiagClass : 'ai_reviewed') ?></span>
              <?php if ($ticketDiagProvider !== ''): ?>
                <span style="font-size:0.76rem;color:var(--on-surface-variant);">Provider: <?= htmlspecialchars($ticketDiagProvider) ?></span>
              <?php endif; ?>
              <?php if ($ticketDiagLatency > 0): ?>
                <span style="font-size:0.76rem;color:var(--on-surface-variant);">Latency: <?= htmlspecialchars((string)$ticketDiagLatency) ?> ms</span>
              <?php endif; ?>
            </div>
            <?php if ($ticketDiagReason !== ''): ?>
              <div style="font-size:0.82rem;color:var(--on-surface);line-height:1.45;">
                <strong>Reason:</strong> <?= htmlspecialchars($ticketDiagReason) ?>
              </div>
            <?php endif; ?>
            <div style="font-size:0.8rem;color:var(--on-surface);line-height:1.45;">
              <?= ai_recommendation_render_html($ticketDiagSuggestion !== '' ? $ticketDiagSuggestion : 'Review diagnostics.') ?>
            </div>
          </div>
        <?php endif; ?>

        <!-- Fingerprint & IP matches -->
        <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">
          <div style="font-size:0.85rem;background:var(--surface-container-low);padding:10px 14px;border-radius:8px;word-break:break-all;color:<?= $fpMatch ? '#059669' : 'var(--error)' ?>;">
            <strong>Fingerprint:</strong> <?= htmlspecialchars($fp ?: 'Not submitted') ?>
            <?= $fpMatch ? '<span class="st-chip st-chip-success" style="margin-left:8px;">Matched ✓</span>' : '<span class="st-chip st-chip-danger" style="margin-left:8px;">No match</span>' ?>
          </div>
          <div style="font-size:0.85rem;background:var(--surface-container-low);padding:10px 14px;border-radius:8px;word-break:break-all;color:<?= $ipMatch ? '#059669' : 'var(--error)' ?>;">
            <strong>IP:</strong> <?= htmlspecialchars($ip ?: 'Not submitted') ?>
            <?= $ipMatch ? '<span class="st-chip st-chip-success" style="margin-left:8px;">Matched ✓</span>' : '<span class="st-chip st-chip-danger" style="margin-left:8px;">No match</span>' ?>
          </div>
        </div>

        <!-- Footer -->
        <div style="display:flex;justify-content:space-between;align-items:center;padding-top:12px;border-top:1px solid var(--surface-container-high);font-size:0.85rem;color:var(--on-surface-variant);flex-wrap:wrap;gap:8px;">
          <span><span class="material-symbols-outlined" style="font-size:0.9rem;vertical-align:middle;">schedule</span> <?= htmlspecialchars($ticket['timestamp']) ?></span>
          <div style="display:flex;align-items:center;gap:8px;margin-left:auto;">
            <div style="position:relative;" class="action-menu">
              <button type="button" class="action-menu-trigger" style="background:var(--surface-container-low);border:1px solid var(--outline-variant);border-radius:8px;padding:6px;cursor:pointer;display:flex;">
                <span class="material-symbols-outlined" style="pointer-events:none;font-size:1rem;color:var(--on-surface-variant);">more_vert</span>
              </button>
              <form method="post" class="action-menu-content" hidden style="position:absolute;right:0;top:calc(100% + 6px);background:var(--surface-container-lowest);border:1px solid var(--outline-variant);border-radius:10px;box-shadow:var(--shadow-ambient);padding:4px;z-index:1000;min-width:160px;">
                <?php csrf_field(); ?>
                <input type="hidden" name="name" value="<?= htmlspecialchars($ticket['name']) ?>">
                <input type="hidden" name="matric" value="<?= htmlspecialchars($ticket['matric']) ?>">
                <input type="hidden" name="reason" value="<?= htmlspecialchars($ticket['message']) ?>">
                <button type="submit" name="manual_action" value="checkin" style="display:flex;align-items:center;gap:8px;width:100%;padding:10px 14px;background:none;border:none;cursor:pointer;border-radius:6px;font-family:inherit;font-size:0.88rem;color:var(--on-surface);transition:background 0.15s;">
                  <span class="material-symbols-outlined" style="font-size:1rem;">login</span> Check-In
                </button>
                <button type="submit" name="manual_action" value="checkout" style="display:flex;align-items:center;gap:8px;width:100%;padding:10px 14px;background:none;border:none;cursor:pointer;border-radius:6px;font-family:inherit;font-size:0.88rem;color:var(--on-surface);transition:background 0.15s;">
                  <span class="material-symbols-outlined" style="font-size:1rem;">logout</span> Check-Out
                </button>
              </form>
            </div>
            <form method="post" class="resolve-ticket-form" style="margin:0;">
              <?php csrf_field(); ?>
              <input type="hidden" name="resolve_ticket" value="<?= htmlspecialchars($ticket['timestamp']) ?>">
              <button type="submit" class="st-btn st-btn-success st-btn-sm resolve-btn" onclick="return confirmResolve(event)">
                <span class="material-symbols-outlined" style="font-size:1rem;">check_circle</span> Resolve
              </button>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (!$hasUnresolved): ?>
      <div style="text-align:center;padding:48px 24px;color:var(--on-surface-variant);grid-column:1/-1;">
        <span class="material-symbols-outlined" style="font-size:3rem;color:var(--outline-variant);display:block;margin-bottom:12px;">celebration</span>
        <p style="font-size:1.1rem;font-weight:600;">All support tickets have been resolved!</p>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div style="text-align:center;padding:48px 24px;color:var(--on-surface-variant);grid-column:1/-1;">
      <span class="material-symbols-outlined" style="font-size:3rem;color:var(--outline-variant);display:block;margin-bottom:12px;">inbox</span>
      <p style="font-size:1.1rem;font-weight:600;">No support tickets submitted yet.</p>
    </div>
  <?php endif; ?>
</div>

<?php if ($hasUnresolved && $ticketTotalPages > 1): ?>
  <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
    <div style="font-size:0.82rem;color:var(--on-surface-variant);">
      Showing <?= (int)($ticketOffset + 1) ?>-<?= (int)min($ticketOffset + $ticketPerPage, $ticketTotal) ?> of <?= (int)$ticketTotal ?> unresolved tickets
    </div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;">
      <?php if ($ticketPage > 1): ?>
        <a class="st-btn st-btn-sm" href="index.php?page=support_tickets&tickets_pg=<?= $ticketPage - 1 ?>">Prev</a>
      <?php endif; ?>
      <?php
      $startPage = max(1, $ticketPage - 2);
      $endPage = min($ticketTotalPages, $ticketPage + 2);
      for ($p = $startPage; $p <= $endPage; $p++):
      ?>
        <a class="st-btn st-btn-sm" href="index.php?page=support_tickets&tickets_pg=<?= $p ?>" style="<?= $p === $ticketPage ? 'background:#1f5d99;color:#fff;border-color:#1f5d99;' : '' ?>"><?= $p ?></a>
      <?php endfor; ?>
      <?php if ($ticketPage < $ticketTotalPages): ?>
        <a class="st-btn st-btn-sm" href="index.php?page=support_tickets&tickets_pg=<?= $ticketPage + 1 ?>">Next</a>
      <?php endif; ?>
    </div>
  </div>
<?php endif; ?>

<script>
  const selectAllTickets = document.getElementById('selectAllTickets');
  const bulkTicketCheckboxes = () => Array.from(document.querySelectorAll('.bulk-ticket-checkbox'));

  if (selectAllTickets) {
    selectAllTickets.addEventListener('change', () => {
      const checked = selectAllTickets.checked;
      bulkTicketCheckboxes().forEach(cb => {
        cb.checked = checked;
      });
    });

    document.addEventListener('change', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('bulk-ticket-checkbox')) {
        const boxes = bulkTicketCheckboxes();
        selectAllTickets.checked = boxes.length > 0 && boxes.every(cb => cb.checked);
      }
    });
  }

  document.addEventListener('click', (e) => {
    // Handle action menu trigger clicks
    const trigger = e.target.closest('.action-menu-trigger');
    if (trigger) {
      e.preventDefault();

      const menuWrapper = trigger.closest('.action-menu');
      if (!menuWrapper) return;

      const parentCard = menuWrapper.closest('.ticket-card');

      const menu = menuWrapper.querySelector('.action-menu-content');
      if (!menu) return;

      // Close all other menus
      document.querySelectorAll('.action-menu').forEach(wrapper => {
        const otherMenu = wrapper.querySelector('.action-menu-content');
        if (!otherMenu || otherMenu === menu) {
          return;
        }
        wrapper.classList.remove('active');
        otherMenu.hidden = true;
        const otherCard = wrapper.closest('.ticket-card');
        if (otherCard) otherCard.style.zIndex = '';
      });

      document.querySelectorAll('.ticket-card').forEach(card => {
        card.style.zIndex = '';
      });
      if (parentCard) {
        parentCard.style.zIndex = '40000';
      }

      // Toggle current menu
      if (menu) {
        const isOpen = menuWrapper.classList.contains('active');
        const nextState = isOpen ? 'none' : 'block';
        menuWrapper.classList.toggle('active', !isOpen);
        menu.hidden = isOpen;
        if (isOpen && parentCard) {
          parentCard.style.zIndex = '';
        }
      }
      return;
    }

    // Clicking outside completely closes any open menus
    if (!e.target.closest('.action-menu')) {
      document.querySelectorAll('.action-menu').forEach(wrapper => {
        wrapper.classList.remove('active');
        const menu = wrapper.querySelector('.action-menu-content');
        if (menu) menu.hidden = true;
      });
      document.querySelectorAll('.ticket-card').forEach(card => {
        card.style.zIndex = '';
      });
    }
  });

  function confirmResolve(e) {
    e.preventDefault();
    const form = e.currentTarget.closest('form');
    window.adminConfirm('Mark as Resolved?', 'This ticket will be marked as resolved.')
      .then((ok) => {
        if (ok && form) form.submit();
      });
    return false;
  }

  <?php if (is_array($flashMessage) && !empty($flashMessage['title'])): ?>
    window.adminAlert(
      <?= json_encode((string)$flashMessage['title']) ?>,
      <?= json_encode((string)($flashMessage['text'] ?? '')) ?>,
      <?= json_encode((string)($flashMessage['type'] ?? 'info')) ?>
    );
  <?php endif; ?>
</script>
