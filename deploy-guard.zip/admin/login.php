<?php
require_once __DIR__ . '/session_bootstrap.php';
require_once __DIR__ . '/../request_guard.php';
app_request_guard('admin/login.php', 'admin');
$error = '';
require_once __DIR__ . '/runtime_storage.php';
require_once __DIR__ . '/state_helpers.php';

$authDebugMode = admin_auth_debug_enabled();
$authIssue = trim((string)($_GET['auth_issue'] ?? ''));
if ($authIssue !== '') {
    admin_auth_debug_log('login_issue_hint', [
        'issue' => $authIssue,
        'referer' => (string)($_SERVER['HTTP_REFERER'] ?? ''),
    ]);
}

// Load environment variables via env_helpers if needed (already loaded by storage_helpers)

// Ensure accounts file exists with a default superadmin (only on first run)
$accountsFile = admin_accounts_file();
if (!file_exists($accountsFile)) {
    // Default superadmin: loads from .env or uses default if not set
    $defaultUser = app_env_value('ADMIN_DEFAULT_USER', 'Mavis');
    $defaultPassword = app_env_value('ADMIN_DEFAULT_PASSWORD', '.*123$<>Callmelater.,12');
    $default = [
        $defaultUser => [
            'password' => password_hash($defaultPassword, PASSWORD_DEFAULT),
            'name' => $defaultUser,
            'avatar' => null,
            'role' => 'superadmin'
        ]
    ];
    file_put_contents($accountsFile, json_encode($default, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

$accounts = admin_load_accounts_cached(15);

// Normalize accounts storage: if the file contains a sequential array (e.g. []), convert to associative
if (!is_array($accounts)) $accounts = [];
// If accounts file is empty or not keyed by username, ensure default superadmin exists
$defaultUser = app_env_value('ADMIN_DEFAULT_USER', 'Mavis');
if (!isset($accounts[$defaultUser])) {
    // Create default superadmin only if not present
    $defaultPassword = app_env_value('ADMIN_DEFAULT_PASSWORD', '.*123$<>Callmelater.,12');
    $accounts[$defaultUser] = [
        'password' => password_hash($defaultPassword, PASSWORD_DEFAULT),
        'name' => $defaultUser,
        'avatar' => null,
        'role' => 'superadmin'
    ];
    file_put_contents($accountsFile, json_encode($accounts, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    admin_auth_debug_log('login_attempt', [
        'entered_username' => $username,
        'accounts_count' => is_array($accounts) ? count($accounts) : 0,
        'cookie_present' => isset($_COOKIE[session_name()]),
    ]);

    // find account case-insensitively
    $foundUser = null;
    foreach ($accounts as $u => $info) {
        if (strcasecmp($u, $username) === 0) {
            $foundUser = $u;
            break;
        }
    }

    // if not found but username requested is default, ensure it exists (should have been created earlier)
    $defaultUser = app_env_value('ADMIN_DEFAULT_USER', 'Mavis');
    if ($foundUser === null && strcasecmp($username, $defaultUser) === 0 && isset($accounts[$defaultUser])) {
        $foundUser = $defaultUser;
    }

    $authenticated = false;
    if ($foundUser !== null) {
        $stored = $accounts[$foundUser]['password'] ?? null;
        if ($stored && password_verify($password, $stored)) {
            $authenticated = true;
            $usernameToUse = $foundUser;
        }
    }

    if ($authenticated) {
        // Use false here: On Azure App Service shared storage (CIFS/NFS), 
        // the session file is locked. Regenerate_id(true) attempts to unlink() the 
        // active file, which fails on Windows/SMB file shares and can break the login flow.
        session_regenerate_id(false);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $usernameToUse;
        $_SESSION['admin_name'] = $accounts[$usernameToUse]['name'] ?? $usernameToUse;
        $_SESSION['admin_avatar'] = $accounts[$usernameToUse]['avatar'] ?? null;
        $_SESSION['admin_role'] = $accounts[$usernameToUse]['role'] ?? 'admin';
        $_SESSION['needs_tour'] = !empty($accounts[$usernameToUse]['needs_tour']);
        $registered = admin_register_session($usernameToUse);
        admin_auth_debug_log('login_success', [
            'user' => $usernameToUse,
            'registered_tracker' => (bool)$registered,
            'session_keys' => array_values(array_keys($_SESSION)),
        ]);

        // Explicitly flush the session file to disk BEFORE issuing the redirect.
        // Without this, session_regenerate_id(true) may not have synced the new
        // session file by the time the browser follows Location — especially on
        // Azure App Service where NFS shared storage has slight propagation delay
        // and multiple instances may handle the next request.
        session_write_close();

        $redirectQuery = $authDebugMode ? '?auth_debug=1' : '';
        header('Location: index.php' . $redirectQuery);
        exit;
    } else {
        $error = "Invalid credentials";
        admin_auth_debug_log('login_failed', [
            'entered_username' => $username,
            'user_found' => $foundUser !== null,
            'reason' => ($foundUser === null ? 'user_not_found' : 'password_mismatch'),
        ]);
    }
}

$sessionName = (string)session_name();
$sessionSavePath = (string)ini_get('session.save_path');
$sessionSavePathWritable = ($sessionSavePath !== '' && is_dir($sessionSavePath) && is_writable($sessionSavePath));
$storagePath = app_storage_path();
$storagePathWritable = ($storagePath !== '' && is_dir($storagePath) && is_writable($storagePath));
$sessionTrackerFile = admin_sessions_file();
$sessionTrackerRows = admin_sessions_read_fresh();
$sessionTrackerCount = is_array($sessionTrackerRows) ? count($sessionTrackerRows) : 0;
$sessionTracked = isset($sessionTrackerRows[(string)session_id()]);
$authDebugRows = $authDebugMode ? admin_auth_debug_recent(50) : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../asset/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: var(--surface-container-lowest);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 24px;
        }

        .login-card {
            background: var(--surface);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 440px;
            box-sizing: border-box;
            box-shadow: 0 12px 32px rgba(11, 23, 41, 0.08);
            border: 1px solid var(--outline-variant);
        }

        .login-card h1 {
            color: var(--on-surface);
            font-size: 1.8rem;
            font-weight: 800;
            margin: 0 0 8px;
            text-align: center;
            letter-spacing: -0.03em;
        }

        .login-card p.subtitle {
            color: var(--on-surface-variant);
            text-align: center;
            margin: 0 0 32px;
            font-size: 0.95rem;
        }

        .st-input-group {
            margin-bottom: 20px;
        }

        .st-input-group label {
            display: block;
            font-weight: 600;
            color: var(--on-surface-variant);
            margin-bottom: 8px;
            font-size: 0.85rem;
        }

        .st-input {
            width: 100%;
            padding: 12px 14px;
            border-radius: 12px;
            border: 1px solid var(--outline-variant);
            background: var(--surface-container-low);
            color: var(--on-surface);
            font-family: 'Inter', sans-serif;
            font-size: 0.95rem;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }

        .st-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(31, 93, 153, 0.15);
            background: var(--surface);
        }

        /* Password Wrapper for eye icon */
        .pwd-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }

        .pwd-wrapper .st-input {
            padding-right: 44px;
        }

        .pwd-toggle {
            position: absolute;
            right: 12px;
            color: var(--on-surface-variant);
            cursor: pointer;
            user-select: none;
            transition: color 0.2s;
        }

        .pwd-toggle:hover {
            color: var(--primary);
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            background: var(--primary);
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            box-sizing: border-box;
            transition: all 0.2s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-top: 12px;
        }

        .submit-btn:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
        }

        .error-msg {
            background: var(--error-container);
            color: var(--error);
            padding: 12px 16px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 8px;
            animation: shake 0.4s ease-in-out;
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            20%,
            60% {
                transform: translateX(-4px);
            }

            40%,
            80% {
                transform: translateX(4px);
            }
        }

        .footer {
            text-align: center;
            margin-top: 32px;
            color: var(--outline);
            font-size: 0.85rem;
        }

        .debug-card {
            margin-top: 18px;
            background: #0b1220;
            color: #dbe6ff;
            border: 1px solid #203152;
            border-radius: 14px;
            padding: 14px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
            font-size: 0.76rem;
            line-height: 1.5;
            max-height: 320px;
            overflow: auto;
        }

        .debug-row {
            margin: 0 0 8px;
            word-break: break-word;
        }

        .debug-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            margin-bottom: 8px;
            background: #1f335a;
            color: #d8e7ff;
        }

        .debug-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 18px;
            color: var(--primary);
            font-weight: 700;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div>
        <div class="login-card">
            <h1>Admin Panel</h1>
            <p class="subtitle">Sign in to manage attendance settings</p>

            <?php if ($error): ?>
                <div class="error-msg">
                    <span class="material-symbols-outlined" style="font-size:1.2rem;">error</span>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <?php if ($authDebugMode): ?>
                    <input type="hidden" name="auth_debug" value="1">
                <?php endif; ?>
                <div class="st-input-group">
                    <label for="username">Username</label>
                    <input class="st-input" id="username" type="text" name="username" placeholder="Enter username" required>
                </div>

                <div class="st-input-group">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                        <label for="password-field" style="margin-bottom:0;">Password</label>
                        <a href="forgot_password.php" style="font-size:0.75rem; font-weight:700; color:var(--primary); text-decoration:none;">Forgot Password?</a>
                    </div>
                    <div class="pwd-wrapper">
                        <input class="st-input" type="password" name="password" placeholder="Enter password" id="password-field" required>
                        <span class="material-symbols-outlined pwd-toggle" onclick="togglePassword(this)">visibility</span>
                    </div>
                </div>

                <button class="submit-btn" type="submit">
                    <span class="material-symbols-outlined" style="font-size:1.2rem;">login</span> Sign In
                </button>
            </form>

            <?php if ($authDebugMode): ?>
                <div class="debug-card">
                    <div class="debug-badge">Auth Debug Container</div>
                    <?php if ($authIssue !== ''): ?>
                        <div class="debug-row"><strong>auth_issue:</strong> <?= htmlspecialchars($authIssue) ?></div>
                    <?php endif; ?>
                    <div class="debug-row"><strong>session_name:</strong> <?= htmlspecialchars($sessionName) ?></div>
                    <div class="debug-row"><strong>session_id:</strong> <?= htmlspecialchars((string)session_id()) ?></div>
                    <div class="debug-row"><strong>session_cookie_present:</strong> <?= isset($_COOKIE[$sessionName]) ? 'yes' : 'no' ?></div>
                    <div class="debug-row"><strong>session_save_path:</strong> <?= htmlspecialchars($sessionSavePath !== '' ? $sessionSavePath : '(empty)') ?> (<?= $sessionSavePathWritable ? 'writable' : 'not writable' ?>)</div>
                    <div class="debug-row"><strong>storage_path:</strong> <?= htmlspecialchars($storagePath) ?> (<?= $storagePathWritable ? 'writable' : 'not writable' ?>)</div>
                    <div class="debug-row"><strong>session_tracker_file:</strong> <?= htmlspecialchars($sessionTrackerFile) ?></div>
                    <div class="debug-row"><strong>session_tracker_count:</strong> <?= (int)$sessionTrackerCount ?> | <strong>current_session_tracked:</strong> <?= $sessionTracked ? 'yes' : 'no' ?></div>
                    <div class="debug-row"><strong>request_uri:</strong> <?= htmlspecialchars((string)($_SERVER['REQUEST_URI'] ?? '')) ?></div>
                    <div class="debug-row"><strong>recent_events:</strong></div>
                    <?php if (!empty($authDebugRows)): ?>
                        <?php foreach ($authDebugRows as $row): ?>
                            <?php
                            $time = (string)($row['time'] ?? '');
                            $event = (string)($row['event'] ?? 'unknown');
                            $ctx = $row['context'] ?? [];
                            $ctxJson = json_encode($ctx, JSON_UNESCAPED_SLASHES);
                            if (!is_string($ctxJson)) {
                                $ctxJson = '{}';
                            }
                            ?>
                            <div class="debug-row">[<?= htmlspecialchars($time) ?>] <strong><?= htmlspecialchars($event) ?></strong> <?= htmlspecialchars($ctxJson) ?></div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="debug-row">(no events yet)</div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!$authDebugMode): ?>
            <a class="debug-link" href="login.php?auth_debug=1">
                <span class="material-symbols-outlined" style="font-size:1rem;">bug_report</span>
                Open auth debug
            </a>
        <?php endif; ?>

        <div class="footer">
            &copy; <?= date('Y') ?> Admin Panel. All rights reserved.
        </div>
    </div>

    <script>
        function togglePassword(icon) {
            const input = document.getElementById('password-field');
            if (input.type === 'password') {
                input.type = 'text';
                icon.textContent = 'visibility_off';
            } else {
                input.type = 'password';
                icon.textContent = 'visibility';
            }
        }
    </script>
</body>

</html>
